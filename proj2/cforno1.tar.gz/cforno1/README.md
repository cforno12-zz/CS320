# Project 2 Cache Simulation

## Student Information
Cristobal Forno

cforno1

B00593480

## Details

Could not figure out hot/cold algorithm.
Did not do extra credit.
